create view vSwitches as
  select `fmerta`.`devices`.`id`               AS `id`,
         `fmerta`.`device_types`.`device_type` AS `type`,
         `fmerta`.`devices`.`name`             AS `name`,
         `fmerta`.`levels`.`level_name`        AS `floor`,
         `fmerta`.`rooms`.`room_name`          AS `room`
  from (((`fmerta`.`devices` join `fmerta`.`device_types`) join `fmerta`.`levels`) join `fmerta`.`rooms` on ((
    (`fmerta`.`devices`.`device_type` = `fmerta`.`device_types`.`id`) and
    (`fmerta`.`devices`.`level` = `fmerta`.`levels`.`id`) and (`fmerta`.`devices`.`room` = `fmerta`.`rooms`.`id`))))
  where (`fmerta`.`devices`.`device_type` = 1);


create trigger archive_password
  before UPDATE
  on users
  for each row
  insert into a_users(login,old_pass,new_pass) values (old.LOGIN,old.PASSWORD,new.PASSWORD);


create view vOnOff as
  select `fmerta`.`devices`.`id`               AS `id`,
         `fmerta`.`device_types`.`device_type` AS `type`,
         `fmerta`.`devices`.`name`             AS `name`,
         `fmerta`.`levels`.`level_name`        AS `floor`,
         `fmerta`.`rooms`.`room_name`          AS `room`,
         `fmerta`.`on_off_types`.`on_off_type` AS `type_of_type`,
         `fmerta`.`on_off`.`icon`              AS `icon`
  from (((((`fmerta`.`devices` join `fmerta`.`device_types`) join `fmerta`.`levels`) join `fmerta`.`rooms`) join `fmerta`.`on_off`) join `fmerta`.`on_off_types` on ((
    (`fmerta`.`devices`.`device_type` = `fmerta`.`device_types`.`id`) and
    (`fmerta`.`devices`.`level` = `fmerta`.`levels`.`id`) and (`fmerta`.`devices`.`room` = `fmerta`.`rooms`.`id`) and
    (`fmerta`.`on_off`.`device_id` = `fmerta`.`devices`.`id`) and
    (`fmerta`.`on_off`.`on_off_type` = `fmerta`.`on_off_types`.`id`))))
  where (`fmerta`.`devices`.`device_type` = 2);


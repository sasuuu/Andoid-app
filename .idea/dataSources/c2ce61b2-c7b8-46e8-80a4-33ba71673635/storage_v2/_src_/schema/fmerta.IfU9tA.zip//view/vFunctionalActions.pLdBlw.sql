create view vFunctionalActions as
  select `fmerta`.`functional_switch_actions`.`id`                       AS `id`,
         `fmerta`.`functional_switch_actions`.`functional_switch_action` AS `functional_switch_action`
  from `fmerta`.`functional_switch_actions`;


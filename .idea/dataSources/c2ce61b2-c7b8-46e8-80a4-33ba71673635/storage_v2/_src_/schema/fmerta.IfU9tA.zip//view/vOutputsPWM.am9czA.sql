create view vOutputsPWM as
  select `fmerta`.`devices`.`id` AS `id`, `fmerta`.`devices`.`device_type` AS `type`
  from (`fmerta`.`devices` join `fmerta`.`device_types` on ((
    (`fmerta`.`devices`.`device_type` = `fmerta`.`device_types`.`id`) and
    ((`fmerta`.`devices`.`device_type` = 5) or (`fmerta`.`devices`.`device_type` = 6)))))
  order by `fmerta`.`devices`.`id`;


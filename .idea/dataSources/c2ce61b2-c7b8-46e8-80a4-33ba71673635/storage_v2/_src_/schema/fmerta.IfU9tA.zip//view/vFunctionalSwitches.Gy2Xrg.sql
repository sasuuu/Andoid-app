create view vFunctionalSwitches as
  select `fmerta`.`devices`.`id`                       AS `id`,
         `fmerta`.`device_types`.`device_type`         AS `type`,
         `fmerta`.`devices`.`name`                     AS `name`,
         `fmerta`.`levels`.`level_name`                AS `floor`,
         `fmerta`.`rooms`.`room_name`                  AS `room`,
         `fmerta`.`functional_switches`.`click_action` AS `click_action`,
         `fmerta`.`functional_switches`.`hold_action`  AS `hold_action`
  from ((((`fmerta`.`devices` join `fmerta`.`device_types`) join `fmerta`.`levels`) join `fmerta`.`rooms`) join `fmerta`.`functional_switches` on ((
    (`fmerta`.`devices`.`device_type` = `fmerta`.`device_types`.`id`) and
    (`fmerta`.`devices`.`level` = `fmerta`.`levels`.`id`) and (`fmerta`.`devices`.`room` = `fmerta`.`rooms`.`id`) and
    (`fmerta`.`devices`.`id` = `fmerta`.`functional_switches`.`device_id`))))
  where (`fmerta`.`devices`.`device_type` = 11);


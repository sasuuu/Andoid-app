create view vUsers as
  select `fmerta`.`users`.`login` AS `login`, `fmerta`.`account_types`.`account_type` AS `type`
  from (`fmerta`.`users` join `fmerta`.`account_types` on ((`fmerta`.`users`.`type` = `fmerta`.`account_types`.`id`)));


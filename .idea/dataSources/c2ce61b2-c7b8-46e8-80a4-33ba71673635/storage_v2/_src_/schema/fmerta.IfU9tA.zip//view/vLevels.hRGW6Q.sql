create view vLevels as
  select `fmerta`.`levels`.`level_name` AS `floor`, `fmerta`.`levels`.`id` AS `id`
  from `fmerta`.`levels`;


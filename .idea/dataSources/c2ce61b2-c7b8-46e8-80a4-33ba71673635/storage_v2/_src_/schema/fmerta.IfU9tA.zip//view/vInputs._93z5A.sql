create view vInputs as
  select `fmerta`.`devices`.`id`          AS `id`,
         `fmerta`.`devices`.`device_type` AS `type`,
         `fmerta`.`devices`.`name`        AS `name`
  from `fmerta`.`devices`
  where ((`fmerta`.`devices`.`device_type` = 1) or (`fmerta`.`devices`.`device_type` = 7) or
         (`fmerta`.`devices`.`device_type` = 8) or (`fmerta`.`devices`.`device_type` = 9) or
         (`fmerta`.`devices`.`device_type` = 10) or (`fmerta`.`devices`.`device_type` = 11))
  order by `fmerta`.`devices`.`id`;


create view vOnOffTypes as
  select `fmerta`.`on_off_types`.`id` AS `id`, `fmerta`.`on_off_types`.`on_off_type` AS `on_off_type`
  from `fmerta`.`on_off_types`;


create function devices_showed()
  returns int
  BEGIN
	#Routine body goes here...
	DECLARE COUNT INT DEFAULT 0;
	SELECT count(*) INTO COUNT FROM `devices` WHERE `devices`.`show`=1;
	RETURN COUNT;
END;


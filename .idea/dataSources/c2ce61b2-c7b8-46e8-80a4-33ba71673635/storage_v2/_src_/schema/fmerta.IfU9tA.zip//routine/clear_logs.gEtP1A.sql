create procedure clear_logs()
  BEGIN
	#Routine body goes here...
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SELECT 'Error occured';
	DELETE FROM `logs`;
END;


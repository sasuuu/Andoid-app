create view vDevices as
  select `fmerta`.`devices`.`id`               AS `id`,
         `fmerta`.`device_types`.`device_type` AS `type`,
         `fmerta`.`devices`.`show`             AS `show`
  from (`fmerta`.`devices` join `fmerta`.`device_types` on ((`fmerta`.`devices`.`device_type` =
                                                             `fmerta`.`device_types`.`id`)))
  order by `fmerta`.`devices`.`id`;


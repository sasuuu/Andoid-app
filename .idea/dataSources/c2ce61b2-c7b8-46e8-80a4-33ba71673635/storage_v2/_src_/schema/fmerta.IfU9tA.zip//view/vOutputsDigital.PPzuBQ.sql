create view vOutputsDigital as
  select `fmerta`.`devices`.`id` AS `id`, `fmerta`.`devices`.`device_type` AS `type`
  from `fmerta`.`devices`
  where ((`fmerta`.`devices`.`device_type` = 2) or (`fmerta`.`devices`.`device_type` = 3) or
         (`fmerta`.`devices`.`device_type` = 4))
  order by `fmerta`.`devices`.`id`;


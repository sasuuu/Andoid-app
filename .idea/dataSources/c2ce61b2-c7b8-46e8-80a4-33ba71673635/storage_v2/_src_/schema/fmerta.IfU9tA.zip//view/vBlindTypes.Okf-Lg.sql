create view vBlindTypes as
  select `fmerta`.`blind_types`.`id` AS `id`, `fmerta`.`blind_types`.`blind_type` AS `blind_type`
  from `fmerta`.`blind_types`;


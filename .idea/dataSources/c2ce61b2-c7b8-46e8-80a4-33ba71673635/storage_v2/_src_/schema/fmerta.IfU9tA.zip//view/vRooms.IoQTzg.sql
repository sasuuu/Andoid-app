create view vRooms as
  select `fmerta`.`rooms`.`room_name` AS `room`, `fmerta`.`rooms`.`id` AS `id`
  from `fmerta`.`rooms`;


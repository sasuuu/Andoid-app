create view vBlinds as
  select `fmerta`.`devices`.`id`               AS `id`,
         `fmerta`.`device_types`.`device_type` AS `type`,
         `fmerta`.`devices`.`name`             AS `name`,
         `fmerta`.`levels`.`level_name`        AS `floor`,
         `fmerta`.`rooms`.`room_name`          AS `room`,
         `fmerta`.`blind_types`.`blind_type`   AS `type_of_type`,
         `fmerta`.`blinds`.`direction`         AS `direction`,
         `fmerta`.`blinds`.`duration_time`     AS `duration`,
         `fmerta`.`blinds`.`icon`              AS `icon`
  from (((((`fmerta`.`devices` join `fmerta`.`device_types`) join `fmerta`.`levels`) join `fmerta`.`rooms`) join `fmerta`.`blinds`) join `fmerta`.`blind_types` on ((
    (`fmerta`.`devices`.`device_type` = `fmerta`.`device_types`.`id`) and
    (`fmerta`.`devices`.`level` = `fmerta`.`levels`.`id`) and (`fmerta`.`devices`.`room` = `fmerta`.`rooms`.`id`) and
    (`fmerta`.`blinds`.`device_id` = `fmerta`.`devices`.`id`) and
    (`fmerta`.`blinds`.`blind_type` = `fmerta`.`blind_types`.`id`))))
  where (`fmerta`.`devices`.`device_type` = 3);


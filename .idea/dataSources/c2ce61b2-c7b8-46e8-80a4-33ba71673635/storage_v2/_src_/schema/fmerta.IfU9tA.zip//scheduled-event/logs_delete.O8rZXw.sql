create definer = fmerta@`%` event logs_delete
  on schedule
    every '1' DAY
      starts '2019-01-14 03:00:00'
  disable
do
  BEGIN
        DELETE FROM `logs` WHERE DATEDIFF(CURRENT_TIMESTAMP,`logs`.`date`)>365;
END;

